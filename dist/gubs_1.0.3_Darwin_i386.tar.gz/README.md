`gubs` is a Go clone of Zach Holman's [bubs](https://github.com/holman/bubs). It bubblerizes letters.

[ ![Download](https://api.bintray.com/packages/shelltoys/binaries/gubs/images/download.svg) ](https://bintray.com/shelltoys/binaries/gubs/_latestVersion)

## Example
```sh
$ gubs Zach Holman
Ⓩ ⓐ ⓒ ⓗ Ⓗ ⓞ ⓛ ⓜ ⓐ ⓝ 
```

## Binary download
Click the download badge above.

## Install from source
```sh
go get -u  github.com/dpritchett/gubs
go install github.com/dpritchett/gubs/cmd/gubs
```
